CREATE TRIGGER DEMO_USERS_T1
  BEFORE INSERT OR UPDATE
  ON DEMO_USERS
  FOR EACH ROW
  begin
:NEW.user_name := upper(:NEW.user_name);
end;
/

