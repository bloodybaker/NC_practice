CREATE TRIGGER BI_STUDENT
  BEFORE INSERT
  ON STUDENT
  FOR EACH ROW
  begin   
  if :NEW."STUDENT_ID" is null then 
    select "STUDENT_SEQ".nextval into :NEW."STUDENT_ID" from dual; 
  end if; 
end;
/

